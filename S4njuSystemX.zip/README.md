# S4nju SYSTEM X
MLBB Game Space booster (S4nju SYSTEM X). Requires Shizuku (running + permission granted).

## Build
1. Create a GitHub repo, upload ALL files of this project (keep the .github folder).
2. Open the Actions tab -> "Build APK" -> run (or just push).
3. Download the APK from the run's Artifacts.

## Notes
- Uses only commands the Android shell allows (Game Mode, sustained performance, DND, RAM cleanup, game pre-compile).
- Each step shows OK or UNSUPPORTED depending on the phone.
- Forcing CPU/GPU clocks directly needs root; not possible with Shizuku alone.
