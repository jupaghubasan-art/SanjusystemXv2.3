package com.sanju.gamespacepo

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val red = Color.parseColor("#E5122D")
    private val card = Color.parseColor("#17171E")

    private lateinit var tvShizuku: TextView
    private lateinit var tvGame: TextView
    private lateinit var tvLog: TextView
    private lateinit var btnPerm: Button
    private lateinit var btnBoost: Button
    private lateinit var btnRestore: Button
    private lateinit var btnLaunch: Button

    private var mode = Booster.Mode.PERFORMANCE
    private var gamePkg: String? = null

    private val binderL = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadL = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { refresh() } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(t: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(12).toFloat()
        }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) }
    }

    private fun box(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(card)
            cornerRadius = dp(14).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        root.addView(label("S4nju SYSTEM X", 30f, red, true))
        root.addView(label("Welcome, Sanju", 14f, Color.LTGRAY))

        // Shizuku card
        val b1 = box()
        tvShizuku = label("", 15f, Color.WHITE, true)
        b1.addView(tvShizuku)
        btnPerm = button("Grant Shizuku permission", red) { onPermClick() }
        b1.addView(btnPerm)
        root.addView(b1)

        // Game card
        val b2 = box()
        tvGame = label("", 15f, Color.WHITE, true)
        b2.addView(tvGame)
        b2.addView(label("Mobile Legends: Bang Bang", 12f, Color.GRAY))
        root.addView(b2)

        // Mode card
        val b3 = box()
        b3.addView(label("Boost mode", 15f, Color.WHITE, true))
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        Booster.Mode.values().forEach { m ->
            group.addView(RadioButton(this).apply {
                id = View.generateViewId()
                text = m.label
                setTextColor(Color.WHITE)
                isChecked = m == mode
                setOnClickListener { mode = m }
            })
        }
        b3.addView(group)
        btnBoost = button("ACTIVATE BOOST", red) { runBoost(false) }
        btnLaunch = button("BOOST & LAUNCH MLBB", Color.parseColor("#B00020")) { runBoost(true) }
        btnRestore = button("Restore defaults", Color.parseColor("#33333D")) { runRestore() }
        b3.addView(btnBoost)
        b3.addView(btnLaunch)
        b3.addView(btnRestore)
        root.addView(b3)

        // Log card
        val b4 = box()
        b4.addView(label("Status", 15f, Color.WHITE, true))
        tvLog = label("Ready.", 12f, Color.LTGRAY).apply { typeface = Typeface.MONOSPACE }
        b4.addView(tvLog)
        root.addView(b4)

        setContentView(ScrollView(this).apply { addView(root) })

        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addBinderDeadListener(deadL)
        Shizuku.addRequestPermissionResultListener(permL)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeBinderDeadListener(deadL)
        Shizuku.removeRequestPermissionResultListener(permL)
        super.onDestroy()
    }

    private fun refresh() {
        val s = ShizukuBridge.state()
        gamePkg = GameScanner.find(packageManager)
        tvShizuku.text = when (s) {
            ShizukuBridge.State.READY -> "Shizuku: CONNECTED ✔"
            ShizukuBridge.State.NO_PERMISSION -> "Shizuku: permission needed"
            ShizukuBridge.State.NOT_RUNNING -> "SHIZUKU REQUIRED — start Shizuku first"
        }
        btnPerm.visibility = if (s == ShizukuBridge.State.READY) View.GONE else View.VISIBLE
        btnPerm.text = if (s == ShizukuBridge.State.NO_PERMISSION)
            "Grant Shizuku permission" else "Open Shizuku app"
        tvGame.text = gamePkg?.let { "MLBB detected ✔  ($it)" } ?: "MLBB not installed"

        val ok = s == ShizukuBridge.State.READY && gamePkg != null
        listOf(btnBoost, btnLaunch, btnRestore).forEach {
            it.isEnabled = ok
            it.alpha = if (ok) 1f else 0.4f
        }
    }

    private fun onPermClick() {
        when (ShizukuBridge.state()) {
            ShizukuBridge.State.NO_PERMISSION -> ShizukuBridge.requestPermission()
            else -> {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i)
                else Toast.makeText(this, "Install Shizuku first", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun log(line: String) = runOnUiThread {
        tvLog.text = if (tvLog.text.toString() == "Ready.") line else tvLog.text.toString() + "\n" + line
    }

    private fun runBoost(launch: Boolean) {
        val pkg = gamePkg ?: return
        tvLog.text = "Applying ${mode.label}…"
        Thread {
            Booster.run(Booster.stepsFor(mode, pkg), ::log)
            log("Done. Items marked ✘ are blocked by this phone's Android/ROM.")
            if (launch) runOnUiThread { launchGame(pkg) }
        }.start()
    }

    private fun runRestore() {
        val pkg = gamePkg ?: return
        tvLog.text = "Restoring…"
        Thread {
            Booster.run(Booster.restoreSteps(pkg), ::log)
            log("Defaults restored.")
        }.start()
    }

    private fun launchGame(pkg: String) {
        val i: Intent? = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i)
    }
}
