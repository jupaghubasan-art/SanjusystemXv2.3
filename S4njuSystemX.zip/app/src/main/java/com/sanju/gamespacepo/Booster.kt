package com.sanju.gamespacepo

/**
 * Only things the Android shell is actually allowed to do are used here.
 * Every step reports OK or UNSUPPORTED from the real command output, so
 * nothing is shown as "boosted" unless the device accepted it.
 * Direct CPU/GPU clock forcing (/sys governors) needs root and is NOT attempted.
 */
object Booster {
    enum class Mode(val label: String) {
        BALANCED("Balanced"),
        PERFORMANCE("Performance"),
        EXTREME("Extreme")
    }

    data class Step(val label: String, val cmd: String)

    private val FAIL = Regex(
        "(unknown command|exception|error|not found|denied|unsupported|usage:|invalid)",
        RegexOption.IGNORE_CASE
    )

    private fun gameMode(mode: String, pkg: String) = Step(
        "Game Mode -> $mode",
        "cmd game set --mode $mode --user 0 $pkg || cmd game mode $mode $pkg"
    )

    private val dndOn = Step("Do Not Disturb (priority)", "cmd notification set_dnd priority")
    private val fixedPerf = Step(
        "Sustained performance mode",
        "cmd power set-fixed-performance-mode-enabled true"
    )
    private val killBg = Step("Free RAM (kill cached apps)", "am kill-all")

    fun stepsFor(mode: Mode, pkg: String): List<Step> = when (mode) {
        Mode.BALANCED -> listOf(gameMode("standard", pkg), dndOn)
        Mode.PERFORMANCE -> listOf(gameMode("performance", pkg), fixedPerf, dndOn)
        Mode.EXTREME -> listOf(
            gameMode("performance", pkg), fixedPerf, dndOn, killBg,
            Step("Pre-compile game (speed-profile)", "cmd package compile -m speed-profile -f $pkg")
        )
    }

    fun restoreSteps(pkg: String): List<Step> = listOf(
        gameMode("standard", pkg),
        Step("Sustained performance mode OFF", "cmd power set-fixed-performance-mode-enabled false"),
        Step("Do Not Disturb OFF", "cmd notification set_dnd off")
    )

    fun run(steps: List<Step>, onLine: (String) -> Unit) {
        for (s in steps) {
            val r = ShizukuBridge.exec(s.cmd)
            val failed = r.code != 0 || FAIL.containsMatchIn(r.out)
            onLine(if (failed) "✘ ${s.label}: UNSUPPORTED on this device" else "✔ ${s.label}")
        }
    }
}
