package com.sanju.gamespacepo

import android.content.pm.PackageManager

object GameScanner {
    // Global, Huawei, Xiaomi and India/other MLBB package names
    val MLBB_PACKAGES = listOf(
        "com.mobile.legends",
        "com.mobilelegends.hwag",
        "com.mobilelegends.mi",
        "com.mobiin.gp"
    )

    fun find(pm: PackageManager): String? = MLBB_PACKAGES.firstOrNull {
        try {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(it, 0)
            true
        } catch (_: Exception) {
            false
        }
    }
}
