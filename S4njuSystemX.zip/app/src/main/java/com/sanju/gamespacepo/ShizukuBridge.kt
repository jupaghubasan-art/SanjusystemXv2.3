package com.sanju.gamespacepo

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/** Runs shell commands with Shizuku (shell-level) privileges. */
object ShizukuBridge {
    const val REQ_CODE = 7001

    enum class State { NOT_RUNNING, NO_PERMISSION, READY }

    data class Result(val code: Int, val out: String)

    fun state(): State {
        return try {
            when {
                !Shizuku.pingBinder() -> State.NOT_RUNNING
                Shizuku.isPreV11() -> State.NOT_RUNNING
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
                else -> State.NO_PERMISSION
            }
        } catch (t: Throwable) {
            State.NOT_RUNNING
        }
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQ_CODE)
        } catch (_: Throwable) {
        }
    }

    /** Shizuku.newProcess is not public in API 13, so call it by reflection. */
    fun exec(cmd: String): Result {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            Result(code, out.trim())
        } catch (t: Throwable) {
            Result(-1, t.javaClass.simpleName + ": " + (t.message ?: ""))
        }
    }
}
